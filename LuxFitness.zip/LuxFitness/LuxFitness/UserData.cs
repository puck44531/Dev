﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LuxFitness
{
    internal class UserData
    {
        public static string Username { get; set; }
        public static string Email { get; set; }
    }
}
